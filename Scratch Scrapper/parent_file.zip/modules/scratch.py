from bs4 import BeautifulSoup
import requests
from proxy import ProxyScraper
import random
from tqdm import tqdm
import json
import re 

proxy_list = ProxyScraper().Scraper()

def scan_all_users_project(user):

    url = f'https://scratch.mit.edu/users/{user}/projects/'
    page = 1
    ids = []

    while True:
        new_url = url+f"?page={page}"
        response = requests.get(new_url,proxies=random.choice(proxy_list))
        if response.status_code == 404:
            break

        soup = BeautifulSoup(response.text, 'html.parser')
        span_class = 'title'
        span_tags = soup.find_all('span', class_=span_class)
        for span_tag in span_tags:
            links = span_tag.find_all('a')
            for link in links:
                ids.append(link.get('href').split("/")[2])
        page += 1
    return ids

def get_user_stats(user):
    projects = scan_all_users_project(user)
    stats = {
        "favorites":0,
        "loves":0,
        "remixes":0,
        "views":0,
    }
    print(projects)
    for id in tqdm(projects, leave=False):
        response = requests.get(f"https://api.scratch.mit.edu/projects/{id}",proxies=random.choice(proxy_list))
        data = response.json()["stats"]
        stats["loves"] += data["loves"]
        stats["favorites"] += data["favorites"]
        stats["remixes"] += data["remixes"]
        stats["views"] += data["views"]
    return stats


def get_followers(user):
        response = requests.get(f"https://scratch.mit.edu/users/{user}/followers/",proxies=random.choice(proxy_list),headers={"Accept-Language":"fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7"})
        soup = BeautifulSoup(response.text, 'html.parser')
        span_tags = soup.find_all('h2')
        pattern = r'\((.*?)\)'
        followers = -1

        for span_tag in span_tags:
            if span_tag.find("a") : 
                followers = re.findall(pattern, span_tag.text)[0]
                print(span_tag.text)
        return followers

def get_score(user)

print(get_followers("griffpatch"))