
class FailedWebsocketConnection(Exception):
    pass