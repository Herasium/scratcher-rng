284.518 usernames in account.txt, free to use

You can use everything in this project, just please add credit (or not ?)

uses scratchattach
